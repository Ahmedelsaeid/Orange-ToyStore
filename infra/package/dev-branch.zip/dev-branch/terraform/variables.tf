variable "mysql_image" { type = string; default = "mysql:8.4" }
variable "mysql_storage_size" { type = string; default = "2Gi" }
variable "mysql_database" { type = string; default = "appdb" }
variable "mysql_user" { type = string; default = "appuser" }
